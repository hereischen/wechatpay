Changelog
==============================

1.1.4 - Aug.13, 2015
------------------------------
- changed post_xml_ssh to post_xml in RefundQuery
- NOTE: for general usage, please use version 1.0
- please do not use WeChatPay from this release


1.1.3 - Aug.11,, 2015
------------------------------
- bug fixing
- NOTE: for general usage, please use version 1.0
- please do not use WeChatPay from this release


1.1.2 - Aug.11,, 2015
------------------------------
- rename package name to wechatpay
- NOTE: for general usage, please use version 1.0
- please do not use WeChatPay from this release

1.1.1 - Aug.11, 2015
------------------------------
- fixed bugs, adding exceptions handling.
- NOTE: for general usage, please use version 1.0


1.1.0 - Aug.03, 2015
------------------------------
- fixed bug in getbill for reconciliations when no bill exists.
- NOTE: for general usage, please use version 1.0

1.0.9 - Jul.30, 2015
------------------------------
- changed name to wechatpay
- NOTE: for general usage, please use version 1.0

1.0.8 - Jul.30, 2015
------------------------------
- changed name to wechatpay
- NOTE: for general usage, please use version 1.0



1.0.7 - Jul.16, 2015
------------------------------
- Added date_validation() in DownloadBill()
- NOTE: for general usage, please use version 1.0


1.0.6 - Jul.13, 2015
------------------------------
- Removed get_access_token()
- Updated get_jsapi_ticket()
- NOTE: for general usage, please use version 1.0


1.0.5 - Jul.07, 2015
------------------------------
- Django ORM added in DownloadBill
- NOTE: for general usage, please use version 1.0

1.0.4 - Jul.07, 2015
------------------------------
- Bug fixing.
- changed DownloadBill().post() to DownloadBill().get_bill()
- NOTE: for general usage, please use version 1.0

1.0.3 - Jul.03, 2015
------------------------------
- Bug fixing.
- NOTE: for general usage, please use version 1.0

1.0.2 - Jul.02, 2015
------------------------------
- Bug fixing.


1.0.1 - Jul.02, 2015
------------------------------

- Changed get_access_token() and get_jsapi_ticket() to get data
  from our production url.
- NOTE: for general usage, please use version 1.0



1.0 - Jun.25, 2015
------------------------------

- Initail commit
