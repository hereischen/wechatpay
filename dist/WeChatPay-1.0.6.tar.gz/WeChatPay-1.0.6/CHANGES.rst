Changelog
==============================

1.0.6 - Jul.07, 2015
------------------------------
- Removed get_access_token()
- Updated get_jsapi_ticket()
- NOTE: for general usage, please use version 1.0


1.0.5 - Jul.07, 2015
------------------------------
- Django ORM added in DownloadBill
- NOTE: for general usage, please use version 1.0

1.0.4 - Jul.07, 2015
------------------------------
- Bug fixing.
- changed DownloadBill().post() to DownloadBill().get_bill()
- NOTE: for general usage, please use version 1.0

1.0.3 - Jul.03, 2015
------------------------------
- Bug fixing.
- NOTE: for general usage, please use version 1.0

1.0.2 - Jul.02, 2015
------------------------------
- Bug fixing.


1.0.1 - Jul.02, 2015
------------------------------

- Changed get_access_token() and get_jsapi_ticket() to get data
  from our production url.
- NOTE: for general usage, please use version 1.0



1.0 - Jun.25, 2015
------------------------------

- Initail commit
