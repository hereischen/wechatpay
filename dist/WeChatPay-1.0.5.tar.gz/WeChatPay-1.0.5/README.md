# WeChat微信支付
------
##Overview
Python-Django WeChat payment API, it contains 4 main classes:
> * UnifiedOrderPay
> * NativeOrderPay 
> * JsAPIOrderPay
> * OrderQuery
> * Refund
> * RefundQuery
> * DownloadBill

------

Installation
------------

Install using pip:

```bash
pip install WeChatPay
```
API
---
