Changelog
==============================

1.0.1 - Jul.02, 2015
------------------------------

- Changed get_access_token() and get_jsapi_ticket() to get data
  from our production url.
- NOTE: for general usage, please user version 1.0



1.0 - Jun.25, 2015
------------------------------

- Initail commit
